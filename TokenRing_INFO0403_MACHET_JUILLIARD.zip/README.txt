* Corentin MACHET
* Quentin JUILLIARD
* INFO0403 - T. BERNARD

Ce projet contient :

bin/ : le répertoire des exécutables
include/ : le répertoire des fichiers d'entête
obj/ : le répertoire des fichiers objets pour la compilation
src/ : le répertoire des fichiers sources (.c)
makefile : exécutez directement 'make' pour compiler
CRTP_INFO0403_MACHET_JUILLIARD.pdf : le rapport au format PDF
