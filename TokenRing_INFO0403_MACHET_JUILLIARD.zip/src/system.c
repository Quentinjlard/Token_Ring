#include "system.h"

void end() {
    exit(EXIT_SUCCESS);
}

void die() {
    exit(EXIT_FAILURE);
}
